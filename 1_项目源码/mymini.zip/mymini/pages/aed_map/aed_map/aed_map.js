Page({
  data: {
    longitude: 0,
    latitude: 0,
    markers: []
  },

  onLoad: function () {
    this.getUserLocation(); // 先获取用户位置并设置 marker
  setTimeout(() => {
    this.addAEDLocations(); // 添加 AED 标记
  }, 500); // 延迟调用，确保用户位置已加载
  },

  getUserLocation: function () {
    const that = this;
    wx.getLocation({
      type: 'wgs84',
      success(res) {
        that.setData({
          longitude: res.longitude,
          latitude: res.latitude,
          markers: [{
            id: 1,
            latitude: res.latitude,
            longitude: res.longitude,
            iconPath: '/pictures/p3.png', // 确保路径正确
            width: 30,
            height: 30
          }]
        });
      },
      fail() {
        wx.showToast({
          title: '获取位置失败，显示默认位置',
          icon: 'none'
        });
        // 设置一个默认位置，例如南京的经纬度
        const defaultLongitude = 118.7915619; // 南京经度
        const defaultLatitude = 32.0615513;    // 南京纬度
        that.setData({
          longitude: defaultLongitude,
          latitude: defaultLatitude,
          markers: [{
            id: 1,
            latitude: defaultLatitude,
            longitude: defaultLongitude,
            iconPath: '/pictures/p3.png', // 确保路径正确
            width: 30,
            height: 30
          }]
        });
      }
    });
  },

  // 添加 AED 服务点的标记
  addAEDLocations: function () {
    const aedMarkers = [
      {
        id: 2,
        latitude: 32.061551, // 南京某服务点1
        longitude: 118.796877,
        iconPath: '/pictures/p4.png', // 自定义 AED 图标
        width: 40,
        height: 40,
        callout: {
          content: 'AED 服务店 1\n地址: 南京鼓楼区 xx 路 123 号',
          color: '#ffffff',
          fontSize: 12,
          borderRadius: 10,
          bgColor: '#007aff',
          padding: 5,
          display: 'BYCLICK' // 点击时显示
        }
      },
      {
        id: 3,
        latitude: 32.045452, // 南京某服务点2
        longitude: 118.781693,
        iconPath: '/pictures/p4.png',
        width: 40,
        height: 40,
        callout: {
          content: 'AED 服务店 2\n地址: 南京秦淮区 xx 路 456 号',
          color: '#ffffff',
          fontSize: 12,
          borderRadius: 10,
          bgColor: '#007aff',
          padding: 5,
          display: 'BYCLICK'
        }
      },
      {
        id: 4,
        latitude: 32.057054, // 南京某服务点3
        longitude: 118.798877,
        iconPath: '/pictures/p4.png',
        width: 40,
        height: 40,
        callout: {
          content: 'AED 服务店 3\n地址: 南京玄武区 xx 路 789 号',
          color: '#ffffff',
          fontSize: 12,
          borderRadius: 10,
          bgColor: '#007aff',
          padding: 5,
          display: 'BYCLICK'
        }
      }
    ];
    const updatedMarkers = this.data.markers.concat(aedMarkers);
    console.log('Updated markers:', updatedMarkers); // 打印 markers 数据
    // 更新 markers 数据
    this.setData({
      markers: updatedMarkers
    });

  },

  // 点击标记点事件
  onMarkerTap: function (e) {
    const markerId = e.markerId;
    const marker = this.data.markers.find(item => item.id === markerId);
    if (marker) {
      wx.showModal({
        title: 'AED 服务点信息',
        content: marker.callout.content.replace('\n', '\n'),
        showCancel: false
      });
    }
  },
  
  returnToLocation: function () {
    wx.getLocation({
      type: 'wgs84',
      success: function (res) {
        wx.openLocation({
          latitude: res.latitude,
          longitude: res.longitude,
          name: '您当前位置',
          address: '当前位置'
        });
      }
    });
  }
});
