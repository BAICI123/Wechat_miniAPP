Page({

  data: {
    knowledgeList: [
      {
        id: 1,
        title: "心肺复苏",
        description: "心肺复苏（CPR）是一种重要的急救方法，适用于心脏骤停的患者。",
      },
      {
        id: 2,
        title: "海姆利克急救法",
        description: "一种用于处理窒息的急救技巧,通过施加腹部压力，帮助被窒息者排出阻塞物，恢复呼吸。",
      },
      {
        id: 3,
        title: "AED的使用",
        description: "AED是一种用于紧急情况下救治心脏骤停患者的医疗设备，可配合心肺复苏大幅提高成功率。",
      },
      {
        id: 4,
        title: "中暑",
        description: "当处于高温、高湿环境时，如果出现多汗、口渴、乏力、眼花、恶心、头痛、头晕等症状时，就要警惕中暑的发生。",
      },
      {
        id: 5,
        title: "烧烫伤处理",
        description: "烧烫伤是一种由于外界高温源，导致患者人体皮肤和黏膜组织或人体皮肤和黏膜皮下组织出现受损",
      },
      {
        id: 6,
        title: "骨折处理",
        description: "骨折的急救是在骨折发生后即时处理，处理不当可能加重损伤，增加患者的痛苦，甚至造成残废，影响生活",
      }
    ]
  },
  
  navigateToLearning: function() {
    wx.navigateTo({
      url: '/pages/index/index' // 假设学习页面的路径
    });
  },

  navigateToAEDMap: function() {
    wx.navigateTo({
      url: '/pages/aed_map/aed_map' // 假设 AED 地图页面的路径
    });
  },

  navigateToDetail: function(event) {
    const index = event.currentTarget.dataset.index; // 获取点击的知识卡片的索引
    const id = event.currentTarget.dataset.id; // 获取点击的知识卡片的 ID
    const knowledgeItem = this.data.knowledgeList[index]; // 获取对应的知识项
  
    // 根据知识项的 ID 跳转到不同的详情页面
    let url;
    switch (id) {
      case 1:
        url = '/pages/detail/detail1/detail1'; //心脏复苏
        break;
      case 2:
        url = '/pages/detail/detail2/detail2'; // 海姆利克详情页面
        break;
      case 3:
        url = '/pages/detail/detail3/detail3'; //aed详情页面
        break;
      case 4:
        url = '/pages/detail/detail4/detail4'; // 中暑详情页面
        break;
      case 5:
        url = '/pages/detail/detail5/detail5'; // 烧烫伤详情页面
        break;
      default:
        url = '/pages/detail/detail6/detail6'; // 默认详情页面
    }

    // 跳转到详情页并传递 index
    wx.navigateTo({
      url: url + '?index=' + index // 传递 index
    });
  }

});
